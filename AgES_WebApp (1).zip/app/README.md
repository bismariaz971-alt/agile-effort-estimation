# AgES effort estimation: web application

Web interface for the XGBoost model of the study "Improving Predictive Accuracy for Agile Software Effort Estimation using Advanced Optimization and Hybrid Techniques".

## Set up
1. Python 3.10 or later. Install the packages: `pip install -r requirements.txt`
2. Copy `Raw_AgES_Dataset.csv` into the `data` folder.
3. Copy `best_params.json` from the `model` folder inside `ages_extension.zip` (made by the extension notebook) into the `model` folder of this application. On first start the application fits the model with these settings (a few minutes at most), stores it with its performance figures, and loads it. Without `best_params.json` it uses the reference settings of the study.
4. Start: `python app.py`, then open http://127.0.0.1:5000

## Pages
* **Predict**: enter repository, category, component, labels, title, description, assignee and creation time. The page returns the estimated duration in days with the median error on unseen repositories.
* **Performance**: metrics of the stored model (random hold-out, repository-grouped hold-out) next to the constant median and the published XGBoost figures, with a chart.
* **Retrain**: upload a CSV of newly closed issues in the same format. The rows are appended, a backup of the previous data is written, the model is refitted with the stored settings, and a new version is saved under `model/versions`.
* **Model**: settings and stored versions.

## Files
`app.py` (routes), `features.py` (feature construction shared by training and prediction; reproduces the set S3 of the study exactly), `train.py` (training, evaluation and storage; also usable from the command line: `python train.py --data data/Raw_AgES_Dataset.csv --out model`).

## Notes
* The model predicts calendar duration from creation to closure on the log scale and reports days. It is intended for ranking and flagging issues. The median error for unseen repositories is several days.
* The hold-out figures on the Performance page are indicative, because the stored settings were tuned on all issues. The unbiased results are the nested results reported in the paper.
* Retraining refits the stored settings and does not repeat the hyperparameter search. To search again, run the extension notebook on the new data.
