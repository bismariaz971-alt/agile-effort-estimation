"""Feature construction shared by training, retraining and prediction.

The features are those of set S3 of the study: category and component indicators, the number of labels, text and calendar fields of the issue,
and history features computed only from issues of the same repository and assignee that were closed before the issue was created.
"""
import ast
import numpy as np
import pandas as pd

M_SHRINK = 5.0
ENG_COLS = ["title_len", "title_words", "body_len_log", "body_has_code", "body_n_links", "created_dow", "created_hour",
            "repo_prior_n_log", "repo_prior_mean", "repo_open_log", "asg_prior_n_log", "asg_prior_mean", "asg_open_log"]
EPOCH = pd.Timestamp("1970-01-01", tz="UTC")


def parse_list(s):
    if isinstance(s, str):
        try:
            v = ast.literal_eval(s)
            return list(v) if isinstance(v, (list, tuple)) else [str(v)]
        except Exception:
            return []
    return []


def prior_stats(keys, tc, tz, yy):
    """Number and sum of target values of earlier closed issues with the same key, and number of issues of that key open at creation."""
    n_prior = np.zeros(len(yy)); s_prior = np.zeros(len(yy)); n_open = np.zeros(len(yy))
    df = pd.DataFrame({"k": keys, "c": tc, "z": tz, "y": yy, "i": np.arange(len(yy))})
    for _, g in df.groupby("k", sort=False):
        order = np.argsort(g["z"].values, kind="stable")
        zs = g["z"].values[order]; cs = np.concatenate([[0.0], np.cumsum(g["y"].values[order])])
        idx = np.searchsorted(zs, g["c"].values, side="left")
        n_prior[g["i"].values] = idx; s_prior[g["i"].values] = cs[idx]
        cr = np.sort(g["c"].values)
        opened = np.searchsorted(cr, g["c"].values, side="right")
        closed = np.searchsorted(zs, g["c"].values, side="right")
        n_open[g["i"].values] = np.clip(opened - closed - 1, 0, None)
    return n_prior, s_prior, n_open


def prepare(raw):
    raw = raw.copy().reset_index(drop=True)
    raw["created"] = pd.to_datetime(raw["Created At"], utc=True, format="mixed")
    raw["closed"] = pd.to_datetime(raw["Closed At"], utc=True, format="mixed")
    raw["t_created"] = (raw["created"] - EPOCH).dt.total_seconds().values
    raw["t_closed"] = (raw["closed"] - EPOCH).dt.total_seconds().values
    raw["days"] = raw["Time Taken (days)"].astype(float)
    raw["y"] = np.log1p(raw["days"])
    raw["assignee1"] = raw["Assignees"].apply(parse_list).apply(lambda a: a[0] if len(a) else "NA")
    return raw


def text_features(title, body):
    title = title.fillna("").astype(str); body = body.fillna("").astype(str)
    return pd.DataFrame({"title_len": title.str.len().astype(float), "title_words": title.str.split().apply(len).astype(float),
                         "body_len_log": np.log1p(body.str.len().astype(float)), "body_has_code": body.str.contains("```", regex=False).astype(float),
                         "body_n_links": body.str.count("http").astype(float)})


def build_training_features(raw, spec):
    """Features of all issues in a prepared frame (training and evaluation)."""
    n = len(raw); y = raw["y"].values
    gn, gs, _ = prior_stats(np.zeros(n), raw["t_created"].values, raw["t_closed"].values, y)
    gmean = np.where(gn > 0, gs / np.maximum(gn, 1), y.mean())
    sh = lambda nn, ss: (ss + M_SHRINK * gmean) / (nn + M_SHRINK)
    repo = raw["Repository"].astype(str).values
    rn, rs, ro = prior_stats(repo, raw["t_created"].values, raw["t_closed"].values, y)
    an, as_, ao = prior_stats(pd.Series(repo).astype(str).values + "|" + raw["assignee1"].values, raw["t_created"].values, raw["t_closed"].values, y)
    F = pd.DataFrame(index=raw.index)
    F["n_labels"] = raw["Labels"].apply(parse_list).apply(len).astype(float)
    F = pd.concat([F, text_features(raw["Title"], raw["Body"])], axis=1)
    F["created_dow"] = raw["created"].dt.dayofweek.astype(float); F["created_hour"] = raw["created"].dt.hour.astype(float)
    F["repo_prior_n_log"] = np.log1p(rn); F["repo_prior_mean"] = sh(rn, rs); F["repo_open_log"] = np.log1p(ro)
    F["asg_prior_n_log"] = np.log1p(an); F["asg_prior_mean"] = sh(an, as_); F["asg_open_log"] = np.log1p(ao)
    cat = "Category_" + raw["Category"].fillna("Unknown").astype(str); comp = "Component_" + raw["Component"].fillna("Unknown").astype(str)
    dummies = {c: (cat == c).astype(float) for c in spec["category_columns"]}
    dummies.update({c: (comp == c).astype(float) for c in spec["component_columns"]})
    F = pd.concat([F, pd.DataFrame(dummies, index=F.index)], axis=1)
    return F[spec["columns"]].astype(np.float32)


def build_new_issue_features(hist, spec, repository, category, component, n_labels, title, body, assignee, created):
    """Features of one new issue, computed from the stored history of closed issues (frame returned by prepare)."""
    t = (pd.Timestamp(created, tz="UTC") - EPOCH).total_seconds() if pd.Timestamp(created).tzinfo is None else (pd.Timestamp(created) - EPOCH).total_seconds()
    ts = pd.Timestamp(t, unit="s", tz="UTC")
    closed_before = hist[hist["t_closed"] < t]
    gmean = closed_before["y"].mean() if len(closed_before) else hist["y"].mean()
    def stats(mask):
        cb = hist[mask & (hist["t_closed"] < t)]
        n_prior = len(cb); s_prior = cb["y"].sum()
        n_open = int(((hist["t_created"] <= t) & (hist["t_closed"] > t) & mask).sum())
        return n_prior, (s_prior + M_SHRINK * gmean) / (n_prior + M_SHRINK), n_open
    rn, rmean, ro = stats(hist["Repository"].astype(str) == repository)
    an, amean, ao = stats((hist["Repository"].astype(str) == repository) & (hist["assignee1"] == (assignee or "NA")))
    tf = text_features(pd.Series([title]), pd.Series([body])).iloc[0]
    row = {"n_labels": float(n_labels), **tf.to_dict(), "created_dow": float(ts.dayofweek), "created_hour": float(ts.hour),
           "repo_prior_n_log": np.log1p(rn), "repo_prior_mean": rmean, "repo_open_log": np.log1p(ro),
           "asg_prior_n_log": np.log1p(an), "asg_prior_mean": amean, "asg_open_log": np.log1p(ao)}
    for c in spec["category_columns"]: row[c] = float(c == "Category_" + str(category))
    for c in spec["component_columns"]: row[c] = float(c == "Component_" + str(component))
    return pd.DataFrame([row])[spec["columns"]].astype(np.float32), dict(repo_prior_issues=rn, assignee_prior_issues=an, repo_open=ro)
