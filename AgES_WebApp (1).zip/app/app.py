"""Web application for the AgES effort estimation model.

Pages: prediction form (/), model performance against the baselines (/evaluate), retraining with new data (/retrain), stored model versions (/model).
Run:  python app.py   then open http://127.0.0.1:5000
"""
import io, json, os, shutil, time
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from flask import Flask, render_template, request, send_file, redirect, url_for, flash
from features import prepare, build_new_issue_features
import train as trainer

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data", "Raw_AgES_Dataset.csv")
MODEL_DIR = os.path.join(BASE, "model")
REQUIRED = ["Repository", "Title", "Body", "Labels", "Assignees", "Created At", "Closed At", "Time Taken (days)", "Category", "Component"]

app = Flask(__name__)
app.secret_key = "ages-effort-estimation"
STATE = {}


def load_state():
    path = os.path.join(MODEL_DIR, "ages_model.joblib")
    if not os.path.exists(path) or not os.path.exists(os.path.join(MODEL_DIR, "metrics.json")):
        trainer.train(DATA, MODEL_DIR, os.path.join(MODEL_DIR, "best_params.json"))
    bundle = joblib.load(path)
    spec_path = os.path.join(MODEL_DIR, "feature_spec.json")
    if not os.path.exists(spec_path):
        raw = prepare(pd.read_csv(DATA)); json.dump(trainer.make_spec(raw), open(spec_path, "w"))
    spec = json.load(open(spec_path)); hist = prepare(pd.read_csv(DATA))
    metrics = json.load(open(os.path.join(MODEL_DIR, "metrics.json"))) if os.path.exists(os.path.join(MODEL_DIR, "metrics.json")) else None
    comp_values = sorted(c.replace("Component_", "", 1) for c in spec["component_columns"])
    cat_values = sorted(c.replace("Category_", "", 1) for c in spec["category_columns"])
    STATE.update(bundle=bundle, spec=spec, hist=hist, metrics=metrics, repos=sorted(hist["Repository"].astype(str).unique()), components=comp_values, categories=cat_values)


def predict_issue(form):
    s = STATE; created = pd.to_datetime(form.get("created") or pd.Timestamp.now(), utc=True)
    X, ctx = build_new_issue_features(s["hist"], s["spec"], form["repository"], form["category"], form["component"], int(form.get("n_labels") or 0),
                                      form.get("title", ""), form.get("body", ""), form.get("assignee", "").strip(), created)
    b = s["bundle"]; log_pred = float(np.clip(b["model"].predict(b["vt"].transform(X.values))[0], 0, b["ymax"]))
    out = dict(log_pred=log_pred, days=float(np.expm1(log_pred)), **ctx)
    m = s["metrics"]
    if m:
        e = m["evaluation_grouped_holdout"]["MdAE"]
        out.update(low=float(max(np.expm1(max(log_pred - e, 0)), 0)), high=float(np.expm1(min(log_pred + e, b["ymax"]))), md_days=m["evaluation_grouped_holdout"]["MdAE_days"])
    return out


@app.route("/", methods=["GET", "POST"])
def index():
    result = None; form = {}
    if request.method == "POST":
        form = request.form.to_dict()
        try: result = predict_issue(form)
        except Exception as exc: flash(f"Prediction failed: {exc}", "error")
    return render_template("index.html", s=STATE, result=result, form=form, now=time.strftime("%Y-%m-%dT%H:%M"))


@app.route("/evaluate")
def evaluate():
    return render_template("evaluate.html", s=STATE, m=STATE["metrics"])


@app.route("/chart.png")
def chart():
    m = STATE["metrics"]
    if not m: return ("No metrics", 404)
    names = ["MAE", "MdAE", "RMSE"]
    series = [("Model, random hold-out", m["evaluation_random_holdout"]), ("Model, unseen repositories", m["evaluation_grouped_holdout"]), ("Constant median", m["evaluation_constant_median"]), ("Published XGBoost", m["published_reference"])]
    fig, ax = plt.subplots(figsize=(7, 3.4)); w = 0.2
    for i, (lab, d) in enumerate(series): ax.bar(np.arange(3) + i * w, [d[k] for k in names], width=w, label=lab)
    ax.set_xticks(np.arange(3) + 1.5 * w); ax.set_xticklabels(names); ax.set_ylabel("Error (log scale)"); ax.legend(frameon=False, fontsize=8); ax.spines[["top", "right"]].set_visible(False)
    buf = io.BytesIO(); plt.tight_layout(); fig.savefig(buf, format="png", dpi=150); plt.close(fig); buf.seek(0)
    return send_file(buf, mimetype="image/png")


@app.route("/retrain", methods=["GET", "POST"])
def retrain():
    info = None
    if request.method == "POST":
        f = request.files.get("file")
        if not f or not f.filename.lower().endswith(".csv"):
            flash("Choose a CSV file.", "error")
        else:
            try:
                new = pd.read_csv(f)
                missing = [c for c in REQUIRED if c not in new.columns]
                if missing: raise ValueError("Missing columns: " + ", ".join(missing))
                old = pd.read_csv(DATA); before = len(old)
                add = new[[c for c in old.columns if c in new.columns]].copy()
                add = add[add["Time Taken (days)"].notna() & add["Closed At"].notna()]
                if "Number" in add.columns and "Number" in old.columns:
                    existing = set(zip(old["Repository"].astype(str), old["Number"].astype(str)))
                    add = add[[(str(r), str(k)) not in existing for r, k in zip(add["Repository"], add["Number"])]]
                if add.empty: raise ValueError("No new closed issues found in the file.")
                comb = pd.concat([old, add], ignore_index=True)
                shutil.copy(DATA, DATA + "." + time.strftime("%Y%m%d_%H%M%S") + ".bak"); comb.to_csv(DATA, index=False)
                info = trainer.train(DATA, MODEL_DIR, os.path.join(MODEL_DIR, "best_params.json")); info["added"] = int(len(comb) - before)
                load_state(); flash(f"Retrained on {len(comb):,} issues ({len(comb) - before:,} added).", "ok")
            except Exception as exc:
                flash(f"Retraining failed: {exc}", "error")
    return render_template("retrain.html", s=STATE, info=info, required=REQUIRED)


@app.route("/model")
def model_page():
    vdir = os.path.join(MODEL_DIR, "versions"); versions = sorted(os.listdir(vdir), reverse=True) if os.path.isdir(vdir) else []
    return render_template("model.html", s=STATE, m=STATE["metrics"], versions=versions, params=STATE["bundle"]["params"])


if __name__ == "__main__":
    load_state(); app.run(host="127.0.0.1", port=5000, debug=False)
