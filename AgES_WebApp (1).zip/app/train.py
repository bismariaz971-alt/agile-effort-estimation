"""Train, store and evaluate the effort estimation model (FR 6 and FR 4).

Usage:  python train.py --data data/Raw_AgES_Dataset.csv --out model
The tuned XGBoost settings come from model/best_params.json (written by the extension notebook). If the file is missing, the reference settings of the study are used.
"""
import argparse, json, os, shutil, time
import joblib
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.feature_selection import VarianceThreshold
from sklearn.metrics import r2_score
from features import prepare, build_training_features

REFERENCE = dict(n_estimators=150, max_depth=6, learning_rate=0.05)
PUBLISHED = dict(MAE=1.34, MdAE=1.13, MSE=2.83, RMSE=1.68)   # log-scale values reported for XGBoost on AgES (Shankar et al., 2026)
VT_THRESHOLD = 0.0475
SEED = 42


def make_spec(raw):
    cats = sorted("Category_" + c for c in raw["Category"].fillna("Unknown").astype(str).unique())
    comps = sorted("Component_" + c for c in raw["Component"].fillna("Unknown").astype(str).unique())
    eng = ["title_len", "title_words", "body_len_log", "body_has_code", "body_n_links", "created_dow", "created_hour",
           "repo_prior_n_log", "repo_prior_mean", "repo_open_log", "asg_prior_n_log", "asg_prior_mean", "asg_open_log"]
    return dict(category_columns=cats, component_columns=comps, columns=cats + comps + ["n_labels"] + eng)


def metrics(yt, yp, dt):
    e = yp - yt; pdays = np.clip(np.expm1(yp), 0, None)
    return dict(MAE=float(np.mean(np.abs(e))), MdAE=float(np.median(np.abs(e))), MSE=float(np.mean(e ** 2)), RMSE=float(np.sqrt(np.mean(e ** 2))),
                R2=float(r2_score(yt, yp)), MAE_days=float(np.mean(np.abs(pdays - dt))), MdAE_days=float(np.median(np.abs(pdays - dt))))


def fit(X, y, params):
    vt = VarianceThreshold(VT_THRESHOLD).fit(X)
    m = xgb.XGBRegressor(tree_method="hist", random_state=SEED, n_jobs=-1, verbosity=0, **params).fit(vt.transform(X), y)
    return vt, m


def train(data_path, out_dir, params_path=None):
    t0 = time.time(); os.makedirs(out_dir, exist_ok=True)
    raw = prepare(pd.read_csv(data_path)); spec = make_spec(raw)
    params = json.load(open(params_path)) if params_path and os.path.exists(params_path) else dict(REFERENCE)
    X = build_training_features(raw, spec).values; y = raw["y"].values; days = raw["days"].values; n = len(y)
    # indicative evaluation: random hold-out and repository-grouped hold-out (parameters were tuned on all data, so these figures are not nested)
    rng = np.random.RandomState(SEED); idx = rng.permutation(n); cut = int(0.8 * n); tr, te = idx[:cut], idx[cut:]
    vt, m = fit(X[tr], y[tr], params); ev_random = metrics(y[te], np.clip(m.predict(vt.transform(X[te])), 0, y.max()), days[te])
    repos = raw["Repository"].astype(str).values; ur = np.array(sorted(set(repos))); rng.shuffle(ur); test_repos = set(ur[: max(1, int(0.2 * len(ur)))])
    te_g = np.array([r in test_repos for r in repos]); vt_g, m_g = fit(X[~te_g], y[~te_g], params)
    ev_group = metrics(y[te_g], np.clip(m_g.predict(vt_g.transform(X[te_g])), 0, y.max()), days[te_g])
    const = float(np.median(y[tr])); ev_const = metrics(y[te], np.full(len(te), const), days[te])
    vt, m = fit(X, y, params)                                    # final model on all issues
    stamp = time.strftime("%Y%m%d_%H%M%S")
    bundle = dict(model=m, vt=vt, columns=spec["columns"], params=params, trained_on=int(n), ymax=float(y.max()), vt_threshold=VT_THRESHOLD, seed=SEED, trained_at=stamp)
    joblib.dump(bundle, os.path.join(out_dir, "ages_model.joblib"))
    os.makedirs(os.path.join(out_dir, "versions"), exist_ok=True); shutil.copy(os.path.join(out_dir, "ages_model.joblib"), os.path.join(out_dir, "versions", f"ages_model_{stamp}.joblib"))
    json.dump(spec | dict(vt_threshold=VT_THRESHOLD, shrink_m=5.0), open(os.path.join(out_dir, "feature_spec.json"), "w"), indent=1)
    info = dict(trained_at=stamp, n_issues=int(n), n_repositories=int(len(ur)), params=params, evaluation_random_holdout=ev_random, evaluation_grouped_holdout=ev_group,
                evaluation_constant_median=ev_const, published_reference=PUBLISHED, seconds=round(time.time() - t0, 1),
                note="Hold-out figures are indicative: the stored parameters were tuned on all issues. Unbiased figures are the nested results in the paper.")
    json.dump(info, open(os.path.join(out_dir, "metrics.json"), "w"), indent=1)
    return info


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--data", default="data/Raw_AgES_Dataset.csv"); ap.add_argument("--out", default="model"); ap.add_argument("--params", default="model/best_params.json")
    a = ap.parse_args(); info = train(a.data, a.out, a.params); print(json.dumps(info, indent=1))
